import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from datetime import datetime

file = sys.argv[1]

df = pd.read_csv(file)

date = []
for i in range(df.shape[0]):
    t = df.iloc[i, 0]
    date.append(datetime.utcfromtimestamp(t).strftime('%d'))
df['date'] = date
date_uni = df.date.unique().tolist()

daily_com_prop = []
daily_avg_com = []
for i in date_uni:
    df_temp = df[df['date']==i].copy()
    daily_com_prop.append(df_temp.shape[0]/df.shape[0])
    daily_avg_com.append(df_temp.shape[0]/df_temp.author.unique().shape[0])

plt.figure(figsize=(10,5), dpi=100)
plt.suptitle('Subreddit: '+file.replace('.csv', ''))
grid = plt.GridSpec(1, 4, wspace=0.4, hspace=0.3)

plt.subplot(grid[0, :2])
ax = plt.gca()
ax.xaxis.set_major_locator(ticker.MultipleLocator(5))
plt.title('Comment Proportion Trend')
plt.xlabel('Date')
plt.ylabel('Proportion')
plt.plot(date_uni, daily_com_prop, 'C1')

plt.subplot(grid[0, 2:])
ax = plt.gca()
ax.xaxis.set_major_locator(ticker.MultipleLocator(5))
ax.yaxis.tick_right()
ax.yaxis.set_label_position("right")
plt.title('Average User Comment Trend')
plt.xlabel('Date')
plt.ylabel('Average')
plt.plot(date_uni, daily_avg_com, 'C2')
plt.savefig('comment_trend_'+file.replace('.csv', '')+'.png')
