import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

file = 'PS4.csv'
df = pd.read_csv('data/'+file)
df = df.dropna(subset=['body'])

date = []
witcher=[]

for i in range(df.shape[0]):
    t = df.iloc[i, 0]
    date.append(datetime.utcfromtimestamp(t).strftime('%d'))

witcher=df["body"].str.contains("witcher")
witcher=witcher.astype('uint8')

df['date'] = date
df["witcher"]= witcher

plt.figure(figsize=(8,6), dpi=100)
plt.title('"Witcher" Frequency')
plt.xlabel('Date')
plt.ylabel('Frequency')
plt.plot(list(range(1,32)) ,df.groupby("date").sum()["witcher"])
plt.savefig('Witcher.png')