import os
import sqlite3
import pandas as pd
import numpy as np

database = sqlite3.connect('database.sqlite')
df = pd.read_sql('SELECT count(subreddit) as count, subreddit FROM May2015 GROUP BY subreddit', database)

df.sort_values('count', inplace = True, ascending = False)
df.head(10)

print('Prop: %3f' % (np.sum(df['count'].values[:100])/np.sum(df['count'].values)))

N = 100
topN = df['subreddit'].values.tolist()[:N]

for name in topN:
    df_sub = pd.read_sql('SELECT * FROM May2015 where subreddit=="'+name+'"', database)
    df_sub.to_csv('data/'+name+'.csv', index = False)
    del df_sub