import pandas as pd
import os

avg = {'subreddit':[],
       'avg_comment':[]}
for (dirpath, dirnames, filenames) in os.walk('data'):
    files = filenames
    break
    
for file in files:
    print('data/'+file)
    df = pd.read_csv('data/'+file)
    avg['subreddit'].append(file.replace('.csv', ''))
    avg['avg_comment'].append(df.shape[0]/df.author.unique().shape[0])

df = pd.DataFrame(avg)
df.to_csv('avg_comment.csv')
