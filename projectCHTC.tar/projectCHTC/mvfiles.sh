#!/bin/bash

mkdir trend_plot wordcloud_plot
mv comment_trend*.png trend_plot
mv wordcloud*.png wordcloud_plot
