#!/bin/bash

wget https://uwmadison.box.com/shared/static/wftk00tc5gblr6w39b3qrf9z1lmwp26w.zip
mv wftk00tc5gblr6w39b3qrf9z1lmwp26w.zip data.zip
unzip data.zip
ls data > files.txt

rm -rf output log error
mkdir output log error

wget https://uwmadison.box.com/shared/static/5tsoe6fpmw9u1ewkdi5gx1ephf3auigd.gz
mv 5tsoe6fpmw9u1ewkdi5gx1ephf3auigd.gz packages.tar.gz

condor_submit trend.sub
condor_submit wordcloud.sub
condor_submit avgcom.sub
